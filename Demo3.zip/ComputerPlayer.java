public class ComputerPlayer {

	private GameConfig config;
	private String movePiece;
	private int currentX;
	private int currentY;
	private int moveX;
	private int moveY;

	public ComputerPlayer(){

	}

	public ComputerPlayer(GameConfig config) {
		this.config = config;
	}

	/*this loops over the entire board. i is for rows, and j is for the columns.
	* it loops over the board , checks the piece and select the best moves. The moves that take
	* pawns are given more value. Sine the paw can only move forward or diagonal, it checks for any
	* pawns either beside or diagonal. As soon as there is a situation where a pawn can be killed, the if statement returns
	* and the program is executed. If there is no such scenario, the computer will loop through all the scenarios and pick the
	* best possible one.
	*/

	public void computeNextMove() {
		int score = 0;
		String[][] board = getBoardCopy();
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				//if there is a white pawn
				if (config.getBoard()[i][j].equals("wP")) {
					//if diagnonally there is a black pawn, kill it
					if (config.isOnBoard(i+1, j+1) && board[i+1][j+1].equals("bP")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wP";
						this.moveX = i+1;
						this.moveY = j+1;
						return;
						//if beside it there is a black pawn, kill it
					} else if (config.isOnBoard(i+1, j-1) && board[i+1][j-1].equals("bP")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wP";
						this.moveX = i+1;
						this.moveY = j-1;
						return;
						//if there is no pawn, kill the knight diagnoally .
					} else if (config.isOnBoard(i+1, j+1) && board[i+1][j+1].equals("bK")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wP";
						this.moveX = i+1;
						this.moveY = j+1;
						score = 1;
						//if there is no pawn, kill the knight beside.
					} else if (config.isOnBoard(i+1, j-1) && board[i+1][j-1].equals("bK")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wP";
						this.moveX = i+1;
						this.moveY = j-1;
						score = 1;
						//if nothing else, move pawn
					}  else if (board[i+1][j] == "__" && (score == 0 || score == -1)) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wP";
						this.moveX = i+1;
						this.moveY = j;
						score = 1;
					}
				}
				//if there is a white knight
				if (config.getBoard()[i][j].equals("wK")) {
					//if theres a black pawn diagonally, kill it
					if (config.isOnBoard(i+1, j+2) && board[i+1][j+2].equals("bP")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i+1;
						this.moveY = j+2;
						return;
						//if theres a black pawn, kill it
					} else if (config.isOnBoard(i+1, j-2) && board[i+1][j-2].equals("bP")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i+1;
						this.moveY = j-2;
						return;
						//if theres a black pawn, kill it
					} else if (config.isOnBoard(i-1, j-2) && board[i-1][j-2].equals("bP")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i-1;
						this.moveY = j-2;
						return;
						//if theres a black pawn, kill it
					} else if (config.isOnBoard(i-1, j+2) && board[i-1][j+2].equals("bP")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i-1;
						this.moveY = j+2;
						return;
						//if theres a black pawn, kill it
					} else if (config.isOnBoard(i+2, j+1) && board[i+2][j+1].equals("bP")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i+2;
						this.moveY = j+1;
						return;
						//if theres a black pawn, kill it
					} else if (config.isOnBoard(i+2, j-1) && board[i+2][j-1].equals("bP")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i+2;
						this.moveY = j-1;
						return;
						//if theres a black pawn, kill it
					} else if (config.isOnBoard(i-2, j+1) && board[i-2][j+1].equals("bP")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i-2;
						this.moveY = j+1;
						return;
						//if theres a black pawn, kill it
					} else if (config.isOnBoard(i-2, j-1) && board[i-2][j-1].equals("bP")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i-2;
						this.moveY = j-1;
						return;
						// if theres a black knight, kill it, for doagnol and beside
					} else if (config.isOnBoard(i+1, j+2) && board[i+1][j+2].equals("bK")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i+1;
						this.moveY = j+2;
						score = 1;
					} else if (config.isOnBoard(i+1, j-2) && board[i+1][j-2].equals("bK")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i+1;
						this.moveY = j-2;
						score = 1;
					} else if (config.isOnBoard(i-1, j-2) && board[i-1][j-2].equals("bK")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i-1;
						this.moveY = j-2;
						score = 1;
					} else if (config.isOnBoard(i-1, j+2) && board[i-1][j+2].equals("bK")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i-1;
						this.moveY = j+2;
						score = 1;
					} else if (config.isOnBoard(i+2, j+1) && board[i+2][j+1].equals("bK")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i+2;
						this.moveY = j+1;
						score = 1;
					} else if (config.isOnBoard(i+2, j-1) && board[i+2][j-1].equals("bK")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i+2;
						this.moveY = j-1;
						score = 1;
					} else if (config.isOnBoard(i-2, j+1) && board[i-2][j+1].equals("bK")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i-2;
						this.moveY = j+1;
						score = 1;
					} else if (config.isOnBoard(i-2, j-1) && board[i-2][j-1].equals("bK")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i-2;
						this.moveY = j-1;
						score = 1;
					}
					//if the score is 0, and the spot is blank, move the peice
					else if (score == 0 && config.isOnBoard(i+1, j+2) && board[i+1][j+2].equals("__")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i+1;
						this.moveY = j+2;
						score = -1;
					} else if (score == 0 && config.isOnBoard(i+1, j-2) && board[i+1][j-2].equals("__")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i+1;
						this.moveY = j-2;
						score = -1;
					} else if (score == 0 && config.isOnBoard(i-1, j-2) && board[i-1][j-2].equals("__")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i-1;
						this.moveY = j-2;
						score = -1;
					} else if (score == 0 && config.isOnBoard(i-1, j+2) && board[i-1][j+2].equals("__")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i-1;
						this.moveY = j+2;
						score = -1;
					} else if (score == 0 && config.isOnBoard(i+2, j+1) && board[i+2][j+1].equals("__")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i+2;
						this.moveY = j+1;
						score = -1;
					} else if (score == 0 && config.isOnBoard(i+2, j-1) && board[i+2][j-1].equals("__")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i+2;
						this.moveY = j-1;
						score = -1;
					} else if (score == 0 && config.isOnBoard(i-2, j+1) && board[i-2][j+1].equals("__")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i-2;
						this.moveY = j+1;
						score = -1;
					} else if (score == 0 && config.isOnBoard(i-2, j-1) && board[i-2][j-1].equals("__")) {
						this.currentX = i;
						this.currentY = j;
						this.movePiece = "wK";
						this.moveX = i-2;
						this.moveY = j-1;
						score = -1;
					}
				}


			}
		}
	}

	private String[][] getBoardCopy() {
		String[][] board = new String[5][5];
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				board[i][j] = config.getBoard()[i][j];
			}
		}
		return board;
	}

	public GameConfig getConfig() {
		return config;
	}

	public String getMovePiece() {
		return movePiece;
	}

	public int getCurrentX() {
		return currentX;
	}

	public int getCurrentY() {
		return currentY;
	}

	public int getMoveX() {
		return moveX;
	}

	public int getMoveY() {
		return moveY;
	}
}
