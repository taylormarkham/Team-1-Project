import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.image.*;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import javafx.scene.text.Font;
import javafx.scene.layout.*;

public class GameGUI extends Application {
	private GameConfig gameBoard = new GameConfig();
	private Move move = new Move();
	private ComputerPlayer computer = new ComputerPlayer(gameBoard);

	private Scene sceneMenu;
	private Scene sceneOptions;
	private Scene sceneHuman;
	private Scene sceneCPU;
	private Color color = Color.GRAY;

	private String piece1;
	private int r1;
	private int c1;
	private int newr1;
	private int newc1;

	private int counter = 0;


	@Override
	public void start(Stage primaryStage) {

		primaryStage.setTitle("Apocalypse Chess");
        	Group rootMenu = new Group();
        	sceneMenu = new Scene(rootMenu, 500, 500, Color.WHITE);

		Group rootOptions = new Group();
        	sceneOptions = new Scene(rootOptions, 500, 500, Color.WHITE);

		Group rootHuman = new Group();
		Scene sceneHuman = new Scene(rootHuman, 500, 500, Color.WHITE);

		Group rootCPU = new Group();
		Scene sceneCPU = new Scene(rootCPU, 500, 500, Color.WHITE);
		computer.computeNextMove();

		Image background = new Image("background.jpg", 500, 500, false, false);
		ImageView bg = new ImageView(background);

		Label title = new Label("Apocalypse Chess");
		title.setFont(new Font("Arial", 50));
		title.setTranslateX(35);
		title.setTranslateY(50);

		Button human = new Button("Human vs. Human");
		human.setTranslateX(15);
		human.setTranslateY(150);
		human.setPrefSize(150,50);

		human.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				counter = counter + 2;
				primaryStage.setScene(sceneHuman);
			}
		});

		Button cpu = new Button("Human vs. Computer");
		cpu.setTranslateX(15);
		cpu.setTranslateY(250);
		cpu.setPrefSize(150,50);

		cpu.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				counter++;
				primaryStage.setScene(sceneCPU);
			}
		});

		Button options = new Button("Options");
		options.setTranslateX(15);
		options.setTranslateY(350);
		options.setPrefSize(150,50);

		options.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				primaryStage.setScene(sceneOptions);
			}
		});

		rootMenu.getChildren().addAll(bg, title, human, cpu, options);

		Label colors = new Label("Tile Colors");
		colors.setFont(new Font("Arial", 50));
		colors.setTranslateX(130);
		colors.setTranslateY(100);

		Button colorRed = new Button("Red with White");
		colorRed.setTranslateX(25);
		colorRed.setTranslateY(200);
		colorRed.setPrefSize(150,50);

		colorRed.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
        			color = Color.RED;
				start(primaryStage);
			}
		});

		Button colorBlue = new Button("Blue with White");
		colorBlue.setTranslateX(25);
		colorBlue.setTranslateY(250);
		colorBlue.setPrefSize(150,50);

		colorBlue.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
        			color = Color.BLUE;
				start(primaryStage);
			}
		});

		Button colorGreen = new Button("Green with White");
		colorGreen.setTranslateX(25);
		colorGreen.setTranslateY(300);
		colorGreen.setPrefSize(150,50);

		colorGreen.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
        			color = Color.GREEN;
				start(primaryStage);
			}
		});

		Button colorGray = new Button("Gray with White (Default)");
		colorGray.setTranslateX(175);
		colorGray.setTranslateY(200);
		colorGray.setPrefSize(150,50);

		colorGray.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
        			color = Color.GRAY;
				start(primaryStage);
			}
		});

		Button colorYellow = new Button("Yellow with White");
		colorYellow.setTranslateX(175);
		colorYellow.setTranslateY(250);
		colorYellow.setPrefSize(150,50);

		colorYellow.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
        			color = Color.YELLOW;
				start(primaryStage);
			}
		});

		Button colorOrange = new Button("Orange with White");
		colorOrange.setTranslateX(175);
		colorOrange.setTranslateY(300);
		colorOrange.setPrefSize(150,50);

		colorOrange.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
        			color = Color.ORANGE;
				start(primaryStage);
			}
		});

		Button colorPurple = new Button("Purple with White");
		colorPurple.setTranslateX(325);
		colorPurple.setTranslateY(200);
		colorPurple.setPrefSize(150,50);

		colorPurple.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
        			color = Color.PURPLE;
				start(primaryStage);
			}
		});

		Button colorPink = new Button("Pink with White");
		colorPink.setTranslateX(325);
		colorPink.setTranslateY(250);
		colorPink.setPrefSize(150,50);

		colorPink.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
        			color = Color.PINK;
				start(primaryStage);
			}
		});

		Button colorBrown = new Button("Brown with White");
		colorBrown.setTranslateX(325);
		colorBrown.setTranslateY(300);
		colorBrown.setPrefSize(150,50);

		colorBrown.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
        			color = Color.PERU;
				start(primaryStage);
			}
		});

		Button back = new Button("Back");
		back.setTranslateY(450);
		back.setPrefSize(100,50);

		back.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
        			primaryStage.setScene(sceneMenu);
			}
		});

		rootOptions.getChildren().addAll(colors, colorRed, colorBlue, colorGreen, colorGray, colorYellow, colorOrange, colorPurple, colorPink, colorBrown, back);


		// Human vs. Human scene

		// creating the board by using 100x100 squares in a for loop
		for (int i = 0; i <= 4; i++) {
			for (int j = 0; j <= 4; j++) {
				Rectangle r = new Rectangle();
				r.setX(j * 100);
				r.setY(i * 100);
				r.setWidth(100);
				r.setHeight(100);
				if ((j % 2 == 0 && i % 2 == 0) || (j % 2 != 0 && i % 2 != 0)) {
					r.setFill(color);
				} else {
					r.setFill(Color.WHITE);
				}
				rootHuman.getChildren().add(r);
			}
		}

		// for loop used to set the initial board AND direct movement of the pieces
		for (int i = 0; i <= 4; i++) {
			for (int j = 0; j <= 4; j++) {
				if (gameBoard.getBoard()[i][j].equals("bP")) {
					Image blackPawn = new Image("blackpawn.png", 100, 100, false, false);
					ImageView bP = new ImageView(blackPawn);

					// placing all the Black Pawns
					rootHuman.getChildren().add(bP);

					bP.setX(j * 100);
					bP.setY(i * 100);

					bP.addEventFilter(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
						@Override
						public void handle(MouseEvent event) {
							int currentY = (int) (bP.getY() / 100);
							int currentX = (int) (bP.getX() / 100);
							int newY = (int) (event.getSceneY() / 100);
							int newX = (int) (event.getSceneX() / 100);
							if (piece1 == "wK" || piece1 == "wP") {
								move.secretMove(piece1, "bP", r1, c1, newr1, newc1, currentY, currentX, newY, newX);
								if (!gameBoard.gameWon())
									start(primaryStage);
								else {
									primaryStage.close();
									System.out.println(" Game Over!");
								}
							}
							else {
								System.out.println("First let White pick a piece to move secretly.");
							}
							piece1 = "bP";
						}
					});
				} else if (gameBoard.getBoard()[i][j].equals("bK")) {
					Image blackKnight = new Image("blackknight.png", 100, 100, false, false);
					ImageView bK = new ImageView(blackKnight);

					rootHuman.getChildren().add(bK);
					bK.setX(j * 100);
					bK.setY(i * 100);


					bK.addEventFilter(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
						@Override
						public void handle(MouseEvent event) {
							int currentY = (int) (bK.getY() / 100);
							int currentX = (int) (bK.getX() / 100);
							int newY = (int) (event.getSceneY() / 100);
							int newX = (int) (event.getSceneX() / 100);
							if (piece1 == "wK" || piece1 == "wP") {
								move.secretMove(piece1, "bK", r1, c1, newr1, newc1, currentY, currentX, newY, newX);
								if (!gameBoard.gameWon())
									start(primaryStage);
								else {
									primaryStage.close();
									System.out.println(" Game Over!");
								}
							}
							else {
								System.out.println("First let White pick a piece to move secretly.");
							}
							piece1 = "bK";
						}
					});
				} else if (gameBoard.getBoard()[i][j].equals("wP")) {
					Image whitePawn = new Image("whitepawn.png", 100, 100, false, false);
					ImageView wP = new ImageView(whitePawn);

					// placing all the White Pawns
					rootHuman.getChildren().add(wP);
					wP.setX(j * 100);
					wP.setY(i * 100);

					wP.addEventFilter(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
						@Override
						public void handle(MouseEvent event) {
							piece1 = "wP";
							r1 = (int) (wP.getY() / 100);
							c1 = (int) (wP.getX() / 100);
							newr1 = (int) (event.getSceneY() / 100);
							newc1 = (int) (event.getSceneX() / 100);
						}
					});

				} else if (gameBoard.getBoard()[i][j].equals("wK")) {
					Image whiteKnight = new Image("whiteknight.png", 100, 100, false, false);
					ImageView wK = new ImageView(whiteKnight);

					// placing all the White Knights
					rootHuman.getChildren().add(wK);
					wK.setX(j * 100);
					wK.setY(i * 100);


					wK.addEventFilter(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
						@Override
						public void handle(MouseEvent event) {
							piece1 = "wK";
							r1 = (int) (wK.getY() / 100);
							c1 = (int) (wK.getX() / 100);
							newr1 = (int) (event.getSceneY() / 100);
							newc1 = (int) (event.getSceneX() / 100);
						}
					});
				}

			}
		}


		// Human vs. Computer scene

		// creating the board by using 100x100 squares in a for loop
		for (int i = 0; i <= 4; i++) {
			for (int j = 0; j <= 4; j++) {
				Rectangle r = new Rectangle();
				r.setX(j * 100);
				r.setY(i * 100);
				r.setWidth(100);
				r.setHeight(100);
				if ((j % 2 == 0 && i % 2 == 0) || (j % 2 != 0 && i % 2 != 0)) {
					r.setFill(color);
				} else {
					r.setFill(Color.WHITE);
				}
				rootCPU.getChildren().add(r);
			}
		}

		// for loop used to set the initial board AND direct movement of the pieces
		for (int i = 0; i <= 4; i++) {
			for (int j = 0; j <= 4; j++) {
				if (gameBoard.getBoard()[i][j].equals("bP")) {
					Image blackPawn = new Image("blackpawn.png", 100, 100, false, false);
					ImageView bP = new ImageView(blackPawn);

					// placing all the Black Pawns
					rootCPU.getChildren().add(bP);
					bP.setX(j * 100);
					bP.setY(i * 100);

					bP.addEventFilter(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
						@Override
						public void handle(MouseEvent event) {
							int currentX = (int) (bP.getY() / 100);
							int currentY = (int) (bP.getX() / 100);
							int newX = (int) (event.getSceneY() / 100);
							int newY = (int) (event.getSceneX() / 100);
							move.secretMove(computer.getMovePiece(), "bP", computer.getCurrentX(), computer.getCurrentY(),
									computer.getMoveX(), computer.getMoveY(), currentX, currentY, newX, newY);
							if (!gameBoard.gameWon())
								start(primaryStage);
							else {
								primaryStage.close();
								System.out.println("Game Over!");
							}
						}
					});
				} else if (gameBoard.getBoard()[i][j].equals("bK")) {
					Image blackKnight = new Image("blackknight.png", 100, 100, false, false);
					ImageView bK = new ImageView(blackKnight);

					rootCPU.getChildren().add(bK);
					bK.setX(j * 100);
					bK.setY(i * 100);

					bK.addEventFilter(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
						@Override
						public void handle(MouseEvent event) {
							int currentX = (int) (bK.getY() / 100);
							int currentY = (int) (bK.getX() / 100);
							int newX = (int) (event.getSceneY() / 100);
							int newY = (int) (event.getSceneX() / 100);
							move.secretMove(computer.getMovePiece(), "bK", computer.getCurrentX(), computer.getCurrentY(),
									computer.getMoveX(), computer.getMoveY(), currentX, currentY, newX, newY);
							if (!gameBoard.gameWon())
								start(primaryStage);
							else {
								primaryStage.close();
								System.out.println("Game Over!");
							}
						}
					});
				} else if (gameBoard.getBoard()[i][j].equals("wP")) {
					Image whitePawn = new Image("whitepawn.png", 100, 100, false, false);
					ImageView wP = new ImageView(whitePawn);

					// placing all the White Pawns
					rootCPU.getChildren().add(wP);
					wP.setX(j * 100);
					wP.setY(i * 100);

				} else if (gameBoard.getBoard()[i][j].equals("wK")) {
					Image whiteKnight = new Image("whiteknight.png", 100, 100, false, false);
					ImageView wK = new ImageView(whiteKnight);

					// placing all the White Knights
					rootCPU.getChildren().add(wK);
					wK.setX(j * 100);
					wK.setY(i * 100);
				}

			}
		}

		if (counter == 1) {
			primaryStage.setScene(sceneCPU);
		}
		else if (counter == 2) {
			primaryStage.setScene(sceneHuman);
		}
		else {
			primaryStage.setScene(sceneMenu);
		}
		primaryStage.show();
	}
}
