import java.util.Scanner;

public class Game{

  public static void main(String[] args){
    int counter = 0;
    GameConfig board = new GameConfig();
    Move move = new Move();
    System.out.println("This is a 5x5 chess board. Rows go from 0-4 and columns go from 0-4. Player 1 controls the White pieces and Player 2 controls the Black pieces. The pieces are White Knight(wK), White Pawn(wP), Black Knight(bK), Black Pawn(bP).\n");
    board.printBoard();
    Scanner keyboard = new Scanner(System.in);
    System.out.println("Would you like to play against the computer or another human? Please enter: Computer or Human ");
    String playerType = keyboard.next();

    while( !playerType.equals("Computer") && !playerType.equals("Human")){
      System.out.println("That is not a valid option. Please pick Computer or Human: ");
      playerType = keyboard.next();
    }

    if( playerType.equals("Human")){
      HumanPlayer player1 = new HumanPlayer();
      HumanPlayer player2 = new HumanPlayer();

      while( board.gameWon() != true){
        // keeping track of turn
        counter++;
        System.out.println("Turn " + counter);

        // getting input from player 1 (white) using methods from human player class
        // add in exception if spot is occupied by another one of your pieces.

        String whitePiece = player1.playerWhite();
        int cRow1 = player1.currentWhiteRow();
        int cCol1 = player1.currentWhiteColumn();
        while( !board.inputMatchesBoard(whitePiece, cRow1, cCol1)){
          System.out.println("That spot on the board does not have that piece. Pick a location where your piece exists: ");
          cRow1 = player1.currentWhiteRow();
          cCol1 = player1.currentWhiteColumn();
        }
        int nRow1 = player1.newWhiteRow();
        int nCol1 = player1.newWhiteColumn();
        while( !move.isValidMove(whitePiece, cRow1, cCol1, nRow1, nCol1) ) {
          System.out.println("That is not a valid move. Please pick a valid spot for your piece: ");
          nRow1 = player1.newWhiteRow();
          nCol1 = player1.newWhiteRow();
        }



        // getting input from player 2 (black) using methods from human player class
        String blackPiece = player2.playerBlack();
        int cRow2 = player2.currentBlackRow();
        int cCol2 = player2.currentBlackColumn();
        while( !board.inputMatchesBoard(blackPiece, cRow2, cCol2)){
          System.out.println("That spot on the board does not have that piece. Pick a location where your piece exists: ");
          cRow2 = player2.currentBlackRow();
          cCol2 = player2.currentBlackColumn();
        }
        int nRow2 = player2.newBlackRow();
        int nCol2 = player2.newBlackColumn();
        while( !move.isValidMove(blackPiece, cRow2, cCol2, nRow2, nCol2) ) {
          System.out.println("That is not a valid move. Please pick a valid spot for your piece: ");
          nRow2 = player2.newBlackRow();
          nCol2 = player2.newBlackRow();
        }

        // calls method from GameConfig class to move pieces
        move.secretMove(whitePiece, blackPiece, cRow1, cCol1, nRow1,
        nCol1, cRow2, cCol2, nRow2, nCol2);
        // reprints updated board
        board.printBoard();
      }
    }
    else if (playerType.equals("Computer")){
      System.out.println("You have picked to play against the computer. You will be player 2. ");
      ComputerPlayer computer = new ComputerPlayer(board);
      HumanPlayer player2 = new HumanPlayer(board);

      while (board.gameWon() != true) {
        // keeping track of turn
        counter++;
        System.out.println("Turn " + counter);

        //Computer computes the next move
        computer.computeNextMove();

        // getting input from player 2 (black) using methods from human player class
        String blackPiece = player2.playerBlack();
        int cRow2 = player2.currentBlackRow();
        int cCol2 = player2.currentBlackColumn();
        while (!board.inputMatchesBoard(blackPiece, cRow2, cCol2)) {
          System.out.println(
          "That spot on the board does not have that piece. Pick a location where your piece exists: ");
          cRow2 = player2.currentBlackRow();
          cCol2 = player2.currentBlackColumn();
        }
        int nRow2 = player2.newBlackRow();
        int nCol2 = player2.newBlackColumn();
        while( !move.isValidMove(blackPiece, cRow2, cCol2, nRow2, nCol2) ) {
          System.out.println("That is not a valid move. Please pick a valid spot for your piece: ");
          nRow2 = player2.newBlackRow();
          nCol2 = player2.newBlackRow();
        }

        // calls method from GameConfig class to move pieces
        move.secretMove(computer.getMovePiece(), blackPiece, computer.getCurrentX(), computer.getCurrentY(), computer.getMoveX(), computer.getMoveY(), cRow2, cCol2, nRow2, nCol2);
        // reprints updated board
        board.printBoard();
      }
    }

  }
}
