public class GameConfig {


	private final static String player1 = "player 1" ;
	private final static String player2 = "player 2" ;
	private final static String WHITE_KNIGHT = "wK";
	private final static String BLACK_KNIGHT = "bK";
	private final static String WHITE_PAWN = "wP";
	private final static String BLACK_PAWN = "bP";
	private final static String BLANK = "__";


	private final static String[][] board = {
		{WHITE_KNIGHT, WHITE_PAWN, WHITE_PAWN, WHITE_PAWN, WHITE_KNIGHT},
		{WHITE_PAWN, BLANK, BLANK, BLANK, WHITE_PAWN},
		{BLANK, BLANK, BLANK, BLANK, BLANK },
		{BLACK_PAWN, BLANK, BLANK, BLANK, BLACK_PAWN},
		{BLACK_KNIGHT, BLACK_PAWN, BLACK_PAWN, BLACK_PAWN, BLACK_KNIGHT}
	};

	/**
	 * Gets the playing board.
	 */
	public static String[][] getBoard(){
		return(board);
	}

	/**
	 * Checks is a piece is on the board.
	 * @param row the row which is being checked.
	 * @param col the column which is being checked.
	 * @return true if the piece is on the board, false if it's not.
	 */
	public boolean isOnBoard(int row, int column) {
		boolean value = false;
		if (row < 5 && column < 5 && row >=0 && column >=0){
			value = true;
		}
		return(value);
	}

	/**
	 * Gets player 1
	 * @return player1
	 */
	public static String getPlayer1(){
		return(player1);
	}

	/**
	 * Gets player 2
	 * @return player2
	 */
	public static String getPlayer2(){
		return(player2);
	}

	/**
	 * Gets white knights
	 * @return white knight
	 */
	public static String getWHITE_KNIGHT(){
		return(WHITE_KNIGHT);
	}

	/**
	 * Gets white pawns
	 * @return white knight
	 */
	public static String getWHITE_PAWN(){
		return(WHITE_PAWN);
	}

	/**
	 * Gets black knights
	 * @return black knight
	 */
	public static String getBLACK_KNIGHT(){
		return(BLACK_KNIGHT);
	}

	/**
	 * Gets black pawns
	 * @return black pawn
	 */
	public static String getBLACK_PAWN(){
		return(BLACK_PAWN);
	}

	/**
	 * Gets the blank spaces
	 * @return blank space
	 */
	public static String getBLANK(){
		return(BLANK);
	}

  /**
	 * Prints the game board.
	 * The board is 5 x 5.
	 * Empty spaces are denoted with __ , black and white knights are bK and wK
	 * respectively, and black and white pawns are bP and wP respectively.
	 */
	public void printBoard(){
		for(int row = 0; row < 5; row++){
			for(int col = 0; col < 5; col++){
				System.out.print(board[row][col] + " " );
			}
			System.out.println();
		}
	}

	/**
	 * Checks if there are any black pawns left on the game board.
	 * @return true is no black pawns are left, false otherwise.
	 */
	public boolean noBlackPawns(){
		boolean nobPawns = true;
		for( int row = 0; row < 5; row++){
			for(int col = 0; col < 5; col++){
				if( board[row][col].equals(BLACK_PAWN)){
					nobPawns = false;
				}
			}
		}
		return(nobPawns);
	}

	/**
	 * Checks if there are any white pawns left on the game board.
	 * @return true is no white pawns are left, false otherwise.
	 */
	public boolean noWhitePawns(){
		boolean nowPawns = true;
		for( int row = 0; row < 5; row++){
			for(int col = 0; col < 5; col++){
				if( board[row][col].equals(WHITE_PAWN)){
					nowPawns = false;
				}
			}
		}
		return(nowPawns);
	}

	/**
	 * Checks to see whether the game has been won.
	 * Game is won if one player has lost all of their pawns.
	 * @return true if the game has been won, false if it has not been won.
	 */
	public boolean gameWon(){
		boolean gameOver = false;
		if (noWhitePawns() == true && noBlackPawns() == true){
			System.out.print("It is a draw!");
			gameOver = true;
		}
		else if( noWhitePawns() == true && noBlackPawns() != true){
			System.out.print("Black has won!");
			gameOver = true;
		}
		else if( noBlackPawns() == true && noWhitePawns() != true ){
			System.out.print("White has won!");
			gameOver = true;
		}
		else{
			gameOver = false;
		}
		return(gameOver);
	}

	/**
	 * Checks that the users input mathches what is on the board.
	 * @param piece the piece being checked.
	 * @param cRow current row of the piece.
	 * @param cCol current column of the piece.
	 */
	public boolean inputMatchesBoard(String piece, int cRow, int cCol){
		boolean validMatch = true;
		if( board[cRow][cCol].equals(piece)){
			validMatch = true;
		}
		else{
			validMatch = false;
		}
		return(validMatch);
	}

}
