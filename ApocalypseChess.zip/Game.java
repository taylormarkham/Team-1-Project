import java.util.Scanner;

/**
 * This class pulls together the methods from other classes to run the game Apocalyse.
 */
public class Game{

  /*
   * The main method calls methods from other classes to run the game and make moves.
   */
  public static void main(String[] args){
    int counter = 0;
    GameConfig board = new GameConfig();
    Move move = new Move();

    board.startOfGame();
    String playerType = board.getPlayerType();

    HumanPlayer player1 = new HumanPlayer();
    HumanPlayer player2 = new HumanPlayer();
    player1.setPlayer("Player 1");
    player2.setPlayer("Player 2");
    ComputerPlayer computerPlayer = new ComputerPlayer(board);
    HumanPlayer humanPlayer = new HumanPlayer();
    humanPlayer.setPlayer("Player 2");

    /*
     * This main loop checks that the game has not been won, and if no one has
     * won, it continues to call methods from other classes and continues to alternate
     * turns between the two players.
     */
    while( board.gameWon() != true){
      if( playerType.equals("Human")){
        move.humanPlayerMove(player1, player2);
      }
      else if( playerType.equals("Computer")){
        move.computerPlayerMove(computerPlayer, humanPlayer);
      }
      board.printBoard();
    }
  }
}
