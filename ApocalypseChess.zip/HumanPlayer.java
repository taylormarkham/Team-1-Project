import java.util.ArrayList;
import java.util.Scanner;

/**
 * This class creates a human player. It allows the human player
 * to choose the piece they want to move, and where they want to move it.
 */
public class HumanPlayer {

	private static Move movement = new Move();
	private String player;
	private String piece;
	private int currentRow;
	private int currentCol;
	private int newRow;
	private int newCol;

	/**
	 * Default constructor
	 */
	public HumanPlayer(){

	}

	/**
	 * Constructor which takes a player as input.
	 * @param player the specified player
	 */
	public HumanPlayer(String player){
		//this.board = config;
		this.player = player;
		this.piece = this.getPiece();
		this.currentRow = this.getCurrentRow();
		this.currentCol = this.getCurrentColumn();
		this.newRow = this.getNewRow();
		this.newCol = this.getNewColumn();
	}

	/**
	 * Sets the player
	 * @param inputPlayer the player being set
	 */
	public void setPlayer(String inputPlayer){
		this.player = inputPlayer;
	}

	/**
	 * Type of piece that the human player wants to move.
	 * @return the type of piece which the player wants to move.
	 */
	public String getPiece() {
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Choose a piece: ");
		String piece = keyboard.next();
		if( this.player.equals("Player 1") ){
			while(!movement.validInputWhite(piece)){
				System.out.println("Invalid input, Enter wK or wP: ");
				piece = keyboard.next();
			}
		}
		else if( this.player.equals("Player 2") ){
			while(!movement.validInputBlack(piece)){
				System.out.println("Invalid input, Enter bK or bP: ");
				piece = keyboard.next();
			}
		}
		return (piece);
	}

	/**
	 * Gets the current row of the piece that the player wants to move
	 * @return the current row which the piece is on.
	 */
	 public int getCurrentRow() {
		 Scanner keyboard = new Scanner(System.in);
		 System.out.print("Which row is this piece on? ");
		 int currentRow = keyboard.nextInt();
		 while (currentRow > 4 || currentRow < 0) {
				 System.out.print("Invalid answer. Please enter a valid row: ");
				 currentRow = keyboard.nextInt();
		 }
	 return (currentRow);
 }

	/**
	 * Gets the current column of the piece that the wants to move
	 * @return the current column which the piece is on.
	 */
	public int getCurrentColumn() {
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Which column is this piece on? ");
		int currentCol = keyboard.nextInt();
		while (currentCol > 4 || currentCol < 0) {
				System.out.print("Invalid answer. Please enter a valid row: ");
				currentCol = keyboard.nextInt();
		}
	return (currentCol);
	}

	/**
	 * Gets the row that the player wants to move their piece to.
	 * @return the new row which the piece is getting moved to.
	 */
	public int getNewRow() {
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Pick a row to move your piece to: ");
		int newRow = keyboard.nextInt();
		while (newRow > 4 || newRow < 0) {
				System.out.print("Invalid answer. Please enter a valid row: ");
				newRow = keyboard.nextInt();
		}
	return (newRow);
	}

	/**
	 * Gets the column that the player wants to move their piece to.
	 * @return the new col which the piece is getting moved to.
	 */
	public int getNewColumn() {
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Pick a row to move your piece to: ");
		int newCol = keyboard.nextInt();
		while (newCol > 4 || newCol < 0) {
				System.out.print("Invalid answer. Please enter a valid row: ");
				newCol = keyboard.nextInt();
			}
	return (newCol);
	}

}
