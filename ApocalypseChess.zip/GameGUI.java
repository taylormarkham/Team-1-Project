import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.image.*;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import javafx.scene.text.Font;

public class GameGUI extends Application {
	//instance variables

	private GameConfig gameBoard = new GameConfig();
	private Move move = new Move();
	private ComputerPlayer computer = new ComputerPlayer(gameBoard);

	//scenes
  private Scene sceneMenu;
  private Scene sceneOptions;
	private Scene sceneHuman;
	private Scene sceneCPU;

	//setting initial tile colors to be gray with white
	private Color color = Color.GRAY;

	//variable used to keep track of the LAST piece that has been clicked on
	private String piece;

	//variables used to keep track of where the last piece's row, column, new row, and new column are
	//these are used to make the simultaneous moves possible, as seen later in the code
	private int pieceRow;
	private int pieceColumn;
	private int pieceNewRow;
	private int pieceNewColumn;

 /**
	* method used to create buttons to change the tile colors in the options menu
	* @param colorName is the name of the color
	* @param x takes the x coordinate on the interface
	* @param y takes the y coordinate on the interface
	* @param c takes the Color
	* @param primaryStage takes the Stage that is being called
	* @param root takes the Group that is being called
	*/
	public void colors(String colorName, int x, int y, Color c, Stage primaryStage, Group rootOptions) {
		Button colorButton = new Button(colorName + " with White");
		colorButton.setTranslateX(x);
		colorButton.setTranslateY(y);
		colorButton.setPrefSize(150,50);

		colorButton.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
        			color = c;
				start(primaryStage);
			}
		});
		rootOptions.getChildren().add(colorButton);
	}

 /**
	* method to create the squares of the board by using 100x100 squares in a for loop
	* @param root takes the Group that is being called
	*/
	public void boardSquares(Group root) {
		for (int i = 0; i <= 4; i++) {
			for (int j = 0; j <= 4; j++) {
				Rectangle r = new Rectangle();
				r.setX(j * 100);
				r.setY(i * 100);
				r.setWidth(100);
				r.setHeight(100);
				if ((j % 2 == 0 && i % 2 == 0) || (j % 2 != 0 && i % 2 != 0)) {
					r.setFill(color);
				} else {
					r.setFill(Color.WHITE);
				}
				root.getChildren().add(r);
			}
		}
	}

 /**
	* method used for the start menu scene
	* @param primaryStage takes the Stage that is being called
	* @param rootMenu takes the Group that is being called
	*/
	public void startMenu(Stage primaryStage, Group rootMenu) {
		Image background = new Image("background.jpg", 500, 500, false, false);
		ImageView bg = new ImageView(background);

		Label title = new Label("Apocalypse Chess");
		title.setFont(new Font("Arial", 50));
		title.setTranslateX(35);
		title.setTranslateY(50);

		Button human = new Button("Human vs. Human");
		human.setTranslateX(15);
		human.setTranslateY(150);
		human.setPrefSize(150,50);

		human.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				primaryStage.setScene(sceneHuman);
			}
		});

		Button cpu = new Button("Human vs. Computer");
		cpu.setTranslateX(15);
		cpu.setTranslateY(250);
		cpu.setPrefSize(150,50);

		cpu.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				primaryStage.setScene(sceneCPU);
			}
		});

		Button options = new Button("Options");
		options.setTranslateX(15);
		options.setTranslateY(350);
		options.setPrefSize(150,50);

		options.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				primaryStage.setScene(sceneOptions);
			}
		});
		rootMenu.getChildren().addAll(bg, title, human, cpu, options);
	}

 /**
	* method used for the options scene
	* @param primaryStage takes the Stage that is being called
	* @param rootOptions takes the Group that is being called
	*/
	public void options(Stage primaryStage, Group rootOptions) {
		Label colors = new Label("Tile Colors");
		colors.setFont(new Font("Arial", 50));
		colors.setTranslateX(130);
		colors.setTranslateY(100);

		Button back = new Button("Back");
		back.setTranslateY(450);
		back.setPrefSize(100,50);

		back.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
        			primaryStage.setScene(sceneMenu);
			}
		});

		rootOptions.getChildren().addAll(colors, back);

		//adding buttons so that the user can choose what tile colors they want on the chess board

		colors("Red", 25, 200, Color.RED, primaryStage, rootOptions);
		colors("Blue", 25, 250, Color.BLUE, primaryStage, rootOptions);
		colors("Green", 25, 300, Color.GREEN, primaryStage, rootOptions);
		colors("Gray", 175, 200, Color.GRAY, primaryStage, rootOptions);
		colors("Yellow", 175, 250, Color.YELLOW, primaryStage, rootOptions);
		colors("Orange", 175, 300, Color.ORANGE, primaryStage, rootOptions);
		colors("Purple", 325, 200, Color.PURPLE, primaryStage, rootOptions);
		colors("Pink", 325, 250, Color.PINK, primaryStage, rootOptions);
		colors("Brown", 325, 300, Color.PERU, primaryStage, rootOptions);

	}

 /**
	* method used for the Human vs. Human scene
	* @param primaryStage takes the Stage that is being called
	* @param rootHuman takes the Group that is being called
	*/
	public void Human(Stage primaryStage, Group rootHuman) {
		// creating the board squares
		boardSquares(rootHuman);

		// for loop used to set the initial board AND direct movement of the pieces
		for (int i = 0; i <= 4; i++) {
			for (int j = 0; j <= 4; j++) {
				if (gameBoard.getBoard()[i][j].equals("bP")) {
					Image blackPawn = new Image("blackpawn.png", 100, 100, false, false);
					ImageView bP = new ImageView(blackPawn);

					// placing all the Black Pawns
					rootHuman.getChildren().add(bP);

					bP.setX(j * 100);
					bP.setY(i * 100);

					bP.addEventFilter(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
						@Override
						public void handle(MouseEvent event) {
							int currentY = (int) (bP.getY() / 100);
							int currentX = (int) (bP.getX() / 100);
							int newY = (int) (event.getSceneY() / 100);
							int newX = (int) (event.getSceneX() / 100);

							if (piece == "wK" || piece == "wP") {
								move.secretMove(piece, "bP", pieceRow, pieceColumn, pieceNewRow, pieceNewColumn, currentY, currentX, newY, newX);
								if (!gameBoard.gameWon())
									Human(primaryStage, rootHuman);
								else {
									primaryStage.close();
									System.out.println(" Game Over!");
								}
								piece = "bP";
							}
							else {
								System.out.println("First let White pick a piece to move secretly.");
							}
						}
					});
				} else if (gameBoard.getBoard()[i][j].equals("bK")) {
					Image blackKnight = new Image("blackknight.png", 100, 100, false, false);
					ImageView bK = new ImageView(blackKnight);

					rootHuman.getChildren().add(bK);
					bK.setX(j * 100);
					bK.setY(i * 100);


					bK.addEventFilter(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
						@Override
						public void handle(MouseEvent event) {
							int currentY = (int) (bK.getY() / 100);
							int currentX = (int) (bK.getX() / 100);
							int newY = (int) (event.getSceneY() / 100);
							int newX = (int) (event.getSceneX() / 100);

							if (piece == "wK" || piece == "wP") {
								move.secretMove(piece, "bK", pieceRow, pieceColumn, pieceNewRow, pieceNewColumn, currentY, currentX, newY, newX);
								if (!gameBoard.gameWon())
									Human(primaryStage, rootHuman);
								else {
									primaryStage.close();
									System.out.println(" Game Over!");
								}
								piece = "bK";
							}
							else {
								System.out.println("First let White pick a piece to move secretly.");
							}
						}
					});
				} else if (gameBoard.getBoard()[i][j].equals("wP")) {
					Image whitePawn = new Image("whitepawn.png", 100, 100, false, false);
					ImageView wP = new ImageView(whitePawn);

					// placing all the White Pawns
					rootHuman.getChildren().add(wP);
					wP.setX(j * 100);
					wP.setY(i * 100);

					wP.addEventFilter(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
						@Override
						public void handle(MouseEvent event) {
							pieceRow = (int) (wP.getY() / 100);
							pieceColumn = (int) (wP.getX() / 100);
							pieceNewRow = (int) (event.getSceneY() / 100);
							pieceNewColumn = (int) (event.getSceneX() / 100);
							piece = "wP";

						}
					});

				} else if (gameBoard.getBoard()[i][j].equals("wK")) {
					Image whiteKnight = new Image("whiteknight.png", 100, 100, false, false);
					ImageView wK = new ImageView(whiteKnight);

					// placing all the White Knights
					rootHuman.getChildren().add(wK);
					wK.setX(j * 100);
					wK.setY(i * 100);


					wK.addEventFilter(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
						@Override
						public void handle(MouseEvent event) {
							pieceRow = (int) (wK.getY() / 100);
							pieceColumn = (int) (wK.getX() / 100);
							pieceNewRow = (int) (event.getSceneY() / 100);
							pieceNewColumn = (int) (event.getSceneX() / 100);
							piece = "wK";

						}
					});
				}

			}
		}
	}

 /**
	* method for the Human vs. CPU scene
	* @param primaryStage takes the Stage that is being called
	* @param rootCPU takes the Group that is being called
	*/
	public void CPU(Stage primaryStage, Group rootCPU) {
		// takes the computer's next move
		computer.computeNextMove();

		// creating the board squares
		boardSquares(rootCPU);

		for (int i = 0; i <= 4; i++) {
			for (int j = 0; j <= 4; j++) {
				if (gameBoard.getBoard()[i][j].equals("bP")) {
					Image blackPawn = new Image("blackpawn.png", 100, 100, false, false);
					ImageView bP = new ImageView(blackPawn);

					// placing all the Black Pawns
					rootCPU.getChildren().add(bP);
					bP.setX(j * 100);
					bP.setY(i * 100);

					bP.addEventFilter(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
						@Override
						public void handle(MouseEvent event) {
							int currentX = (int) (bP.getY() / 100);
							int currentY = (int) (bP.getX() / 100);
							int newX = (int) (event.getSceneY() / 100);
							int newY = (int) (event.getSceneX() / 100);

							move.secretMove(computer.getPiece(), "bP", computer.getCurrentRow(), computer.getCurrentColumn(),
									computer.getNewRow(), computer.getNewColumn(), currentX, currentY, newX, newY);
							if (!gameBoard.gameWon()) {
								CPU(primaryStage, rootCPU);
							}
							else {
								primaryStage.close();
								System.out.println(" Game Over!");
							}
						}
					});
				} else if (gameBoard.getBoard()[i][j].equals("bK")) {
					Image blackKnight = new Image("blackknight.png", 100, 100, false, false);
					ImageView bK = new ImageView(blackKnight);

					rootCPU.getChildren().add(bK);
					bK.setX(j * 100);
					bK.setY(i * 100);

					bK.addEventFilter(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
						@Override
						public void handle(MouseEvent event) {
							int currentX = (int) (bK.getY() / 100);
							int currentY = (int) (bK.getX() / 100);
							int newX = (int) (event.getSceneY() / 100);
							int newY = (int) (event.getSceneX() / 100);

							move.secretMove(computer.getPiece(), "bK", computer.getCurrentRow(), computer.getCurrentColumn(),
									computer.getNewRow(), computer.getNewColumn(), currentX, currentY, newX, newY);
							if (!gameBoard.gameWon()) {
								CPU(primaryStage, rootCPU);
							}
							else {
								primaryStage.close();
								System.out.println(" Game Over!");
							}
						}
					});
				} else if (gameBoard.getBoard()[i][j].equals("wP")) {
					Image whitePawn = new Image("whitepawn.png", 100, 100, false, false);
					ImageView wP = new ImageView(whitePawn);

					// placing all the White Pawns
					rootCPU.getChildren().add(wP);
					wP.setX(j * 100);
					wP.setY(i * 100);

				} else if (gameBoard.getBoard()[i][j].equals("wK")) {
					Image whiteKnight = new Image("whiteknight.png", 100, 100, false, false);
					ImageView wK = new ImageView(whiteKnight);

					// placing all the White Knights
					rootCPU.getChildren().add(wK);
					wK.setX(j * 100);
					wK.setY(i * 100);
				}

			}
		}
	}

 /**
	* start method
	* @param primaryStage takes the Stage that is being called
	*/
	@Override
	public void start(Stage primaryStage) {
		primaryStage.setTitle("Apocalypse Chess");

		Group rootMenu = new Group();
        	sceneMenu = new Scene(rootMenu, 500, 500, Color.WHITE);

		Group rootOptions = new Group();
        	sceneOptions = new Scene(rootOptions, 500, 500, Color.WHITE);

		Group rootHuman = new Group();
		sceneHuman = new Scene(rootHuman, 500, 500, Color.WHITE);

		Group rootCPU = new Group();
		sceneCPU = new Scene(rootCPU, 500, 500, Color.WHITE);

		// Creating the  start menu scene
		startMenu(primaryStage, rootMenu);

		// Creating the options menu scene
		options(primaryStage, rootOptions);

		// Creating the Human vs. Human scene
		Human(primaryStage, rootHuman);

		// Creating the Human vs. Computer scene
		CPU(primaryStage, rootCPU);

		primaryStage.setScene(sceneMenu);
		primaryStage.show();

	}

}
