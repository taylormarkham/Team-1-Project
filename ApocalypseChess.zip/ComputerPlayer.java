/**
 * This class deals with the moves of the AI for the human vs. computer option.
 */
public class ComputerPlayer {

	private GameConfig board = new GameConfig();
	private Move move = new Move();
	private String piece;
	private int currentRow;
	private int currentColumn;
	private int newRow;
	private int newColumn;

	/**
	 * Default constructor
	 */
	public ComputerPlayer(){
	}

	/**
	 * Constructor which takes a game board as input.
	 * @return the board that the pieces will be moved on.
	 */
	public ComputerPlayer(GameConfig board) {
		this.board = board;
	}

	/**
	 * Gets the piece that will be moved.
	 * @return the piece
	 */
	public String getPiece() {
		return piece;
	}

	/**
	 * Gets the current row of the piece.
	 * @return the current row of the computer player's piece
	 */
	public int getCurrentRow() {
		return currentRow;
	}

	/**
	 * Gets the current column of the piece.
	 * @return the current column of the computer player's piece.
	 */
	public int getCurrentColumn() {
		return currentColumn;
	}

	/**
	 * Gets the row that the piece will be moved to.
	 * @return the row which the piece will be moved to
	 */
	public int getNewRow() {
		return newRow;
	}

	/**
	 * Gets the column that the piece will be moved to.
	 * @return the column which the piece will be moved to
	 */
	public int getNewColumn() {
		return newColumn;
	}

	/**
	 * Gets the board.
	 * @return the board
	 */

	public GameConfig getBoard() {
		return this.board;
	}

	/**
	 * This loops over the entire board. i is for rows, and j is for the columns.
	 * It loops over the board, checks the first piece and tries to select a move.
	 * It first checks if the piece can take a pawn.
	 * If there is no pawn to take, then it checks if it can take a knight.
	 * If there is no knight to take, then it checks if it can move to a blank space.
	 * If there is no blank space to move to, then it checks the second piece, third piece... and so on until computer player moves a piece.
	 */
	public void computeNextMove() {
		// count is used to make sure that the computer player is only moving once per turn
		int count = 0;

		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				//if there is a white pawn
				if (board.getBoard()[i][j].equals("wP")) {
					//if there is a pawn, kill it in the diagonal
					count = movementPawn("bP", i, j, i + 1, j + 1, count);

					//if there is a knight, kill it in the diagonal
					count = movementPawn("bK", i, j, i + 1, j + 1, count);

					//if nothing else, move pawn
					count = movementPawn("__", i, j, i + 1, j, count);
				}
				//if there is a white knight
				else if (board.getBoard()[i][j].equals("wK")) {
					//if theres a black pawn, kill it
					count = movementKnight("bP", i, j, i + 1, j + 2, count);
					count = movementKnight("bP", i, j, i + 1, j - 2, count);
					count = movementKnight("bP", i, j, i - 1, j - 2, count);
					count = movementKnight("bP", i, j, i - 1, j + 2, count);
					count = movementKnight("bP", i, j, i + 2, j + 1, count);
					count = movementKnight("bP", i, j, i + 2, j -1, count);
					count = movementKnight("bP", i, j, i - 2, j + 1, count);
					count = movementKnight("bP", i, j, i - 2, j - 1, count);

					// if theres a black knight, kill it
					count = movementKnight("bK", i, j, i + 1, j + 2, count);
					count = movementKnight("bK", i, j, i + 1, j - 2, count);
					count = movementKnight("bK", i, j, i - 1, j - 2, count);
					count = movementKnight("bK", i, j, i - 1, j + 2, count);
					count = movementKnight("bK", i, j, i + 2, j + 1, count);
					count = movementKnight("bK", i, j, i + 2, j - 1, count);
					count = movementKnight("bK", i, j, i - 2, j + 1, count);
					count = movementKnight("bK", i, j, i - 2, j - 1, count);

					//if the spot is blank, move the piece
					count = movementKnight("__", i, j, i + 1, j + 2, count);
					count = movementKnight("__", i, j, i + 1, j - 2, count);
					count = movementKnight("__", i, j, i - 1, j - 2, count);
					count = movementKnight("__", i, j, i - 1, j + 2, count);
					count = movementKnight("__", i, j, i + 2, j + 1, count);
					count = movementKnight("__", i, j, i + 2, j - 1, count);
					count = movementKnight("__", i, j, i - 2, j + 1, count);
					count = movementKnight("__", i, j, i - 2, j - 1, count);
				}
			}
		}
	}

	/**
	 * Method for moving computer player's pawn
	 * @param blackPieceOrBlank the black player's (human player) piece or a blank spot on the board
	 * @param currentRow the current row of the pawn
	 * @param currentColumn the current column of the pawn
	 * @param newRow the row which the pawn will be moved to. Also the row that blackPieceOrBlank can be on on
	 * @param newColumn the column which the pawn will be moved to. Also the column that blackPieceOrBlank can be on
	 * @param count the amount of times the computer player has moved in a turn. It can only be 0 or 1
	 * returns 1 if the pawn can reach the space that blackPieceOrBlank is on and if computer player has not made a move.
	 * @return count otherwise
	 */
	public int movementPawn(String blackPieceOrBlank, int currentRow, int currentColumn, int newRow, int newColumn, int count) {
		if (board.isOnBoard(newRow, newColumn) && board.getBoard()[newRow][newColumn].equals(blackPieceOrBlank) && count == 0) {
			this.piece = "wP";
			this.currentRow = currentRow;
			this.currentColumn = currentColumn;
			this.newRow = newRow;
			this.newColumn = newColumn;
			return 1;
		}
		else {
			return count;
		}
	}

	/**
	 * Method for moving computer player's knight
	 * @param blackPieceOrBlank the black player's (human player) piece or a blank spot on the board
	 * @param currentRow the current row of the knight
	 * @param currentColumn the current column of the knight
	 * @param newRow the row which the knight will be moved to. Also the row that blackPieceOrBlank can be on
	 * @param newColumn the column which the knight will be moved to. Also the column that blackPieceOrBlank can be on
	 * @param count the amount of times the computer player has moved in a turn. It can only be 0 or 1
	 * @return 1 if the knight can reach the space that blackPieceOrBlank is on and if computer player has not made a move.
	 * @return count otherwise
	 */
	public int movementKnight(String blackPieceOrBlank, int currentRow, int currentColumn, int newRow, int newColumn, int count) {
		if (board.isOnBoard(newRow, newColumn) && board.getBoard()[newRow][newColumn].equals(blackPieceOrBlank) && count == 0) {
			this.piece = "wK";
			this.currentRow = currentRow;
			this.currentColumn = currentColumn;
			this.newRow = newRow;
			this.newColumn = newColumn;
			return 1;
		}
		else {
			return count;
		}
	}
}
