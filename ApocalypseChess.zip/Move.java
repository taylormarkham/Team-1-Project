import java.util.Scanner;

/**
 * This class provides the logic for the movements of the pieces.
 */
public class Move extends GameConfig{

  /**
   * Checks if the user is entering a valid piece for the black player.
   * @param piece the piece which is being checked.
   */
  public boolean validInputBlack( String piece){
    boolean validBlackPiece = true;
    if(  piece.equals(super.getBLACK_PAWN()) || piece.equals(super.getBLACK_KNIGHT())){
      validBlackPiece = true;
    }
    else{
      validBlackPiece = false;
    }
    return(validBlackPiece);
  }

  /**
   * Checks if user is entering a valid piece for the white player.
   * @param piece the piece which is being checked.
   */
  public boolean validInputWhite( String piece){
    boolean validWhitePiece = true;
    if(  piece.equals(super.getWHITE_PAWN()) || piece.equals(super.getWHITE_KNIGHT())){
      validWhitePiece = true;
    }
    else{
      validWhitePiece = false;
    }
    return(validWhitePiece);
  }

  /**
   * Checks if a space is empty
   * @param row the row number of the space being checked.
   * @param col the column number of the space being checked.
   */
  public boolean emptySpace(int row, int col){
    return(super.getBoard()[row][col].equals(super.getBLANK()) );
  }

  /**
   * Places a piece is a new spot.
   * @param piece the piece which is to be placed on the new spot.
   * @param row the row number of the new spot.
   * @param col the column number of the new spot.
   */
  public void writeChar(String piece, int row, int col){
    super.getBoard()[row][col] = piece;
  }

  /**
   * Moves a piece to a new spot and updates the original spot to be empty.
   * @param piece the piece which is being moved.
   * @param currentRow the original row which the piece is sitting.
   * @param currentCol the original column which the piece is sitting.
   * @param newRow the row number which the piece is being moved to.
   * @param newRow the column number which the piece is being moved to.
   */
  public void moveChar(String piece, int currentRow, int currentCol, int newRow, int newCol){
    writeChar(super.getBLANK(), currentRow, currentCol);
    //emptySpace(currentRow,currentCol);
    writeChar(piece, newRow, newCol);
  }


  /**
   * Checks if a spot is valid for a knight to be moved to.
   * The spot is valid as long as it is not occupied by one of that players other pieces.
   * @param piece the piece being moved.
   * @param currentRow the original row which the piece is sitting.
   * @param currentCol the original column which the piece is sitting.
   * @param newRow the row number which the piece is being moved to.
   * @param newRow the column number which the piece is being moved to.
   */
  public void validSpotKnight(String piece, int currentRow, int currentCol, int newRow, int newCol){
    if( piece.equals(super.getWHITE_KNIGHT()) ){
      if( !super.getBoard()[newRow][newCol].equals(piece) && !super.getBoard()[newRow][newCol].equals(super.getWHITE_PAWN())){
        moveChar(piece, currentRow, currentCol, newRow, newCol);
      }
    }
    else if( piece.equals(super.getBLACK_KNIGHT())){
      if( !super.getBoard()[newRow][newCol].equals(piece) && !super.getBoard()[newRow][newCol].equals(super.getBLACK_PAWN())){
        moveChar(piece, currentRow, currentCol, newRow, newCol);
      }
    }
  }

  /**
   * Allows the user to move a knight as long as they are making a valid move.
   * Knights move in an "L" shape. They can take the oponents pawns or knights.
   * Checks that the user is making a valid knight move.
   * @param piece the piece being moved.
   * @param currentRow the original row which the piece is sitting.
   * @param currentCol the original column which the piece is sitting.
   * @param newRow the row number which the piece is being moved to.
   * @param newRow the column number which the piece is being moved to.
   * @return true if attempted move is valid for a knight, false otherwise.
   */
  public boolean moveKnight(String piece, int currentRow, int currentCol, int newRow, int newCol){
    boolean validKnightMove = true;
    if( (newRow == currentRow + 1 && newCol == currentCol + 2) ||
    ( newRow == currentRow + 1 && newCol == currentCol - 2) ||
    ( newRow == currentRow - 1 && newCol == currentCol + 2) ||
    ( newRow == currentRow - 1 && newCol == currentCol - 2) ||
    ( newRow == currentRow + 2 && newCol == currentCol + 1) ||
    ( newRow == currentRow + 2 && newCol == currentCol - 1) ||
    ( newRow == currentRow - 2 && newCol == currentCol + 1) ||
    ( newRow == currentRow - 2 && newCol == currentCol - 1)) {
      validSpotKnight(piece, currentRow, currentCol, newRow, newCol);
      validKnightMove = true;
    }
    else{
      validKnightMove = false;
    }
    return(validKnightMove);
  }

  /**
   * This method is for moving the black player's pawns.
   * Pawns can move 1 space forward and only if the space is empty.
   * Pawns may take another piece by moving 1 space on a diagonal.
   * @param piece the piece being moved.
   * @param currentRow the original row which the piece is sitting.
   * @param currentCol the original column which the piece is sitting.
   * @param newRow the row number which the piece is being moved to.
   * @param newRow the column number which the piece is being moved to.
   */
  public void legalpawnMove(String piece, int currentRow, int currentCol, int newRow, int newCol){
    if( newCol == currentCol && newRow == currentRow - 1 && emptySpace(newRow, newCol) == true){
      moveChar(piece, currentRow, currentCol, newRow, newCol);
    }
    if( (emptySpace(newRow, newCol) == false) && (newRow == currentRow - 1) && (newCol == currentCol + 1 || newCol == currentCol - 1)){
      moveChar(piece, currentRow, currentCol, newRow, newCol);
    }
  }

  /**
   * This method changes a black pawn to a knight if it reaches the other side of the board.
   * uses legalpawnMove to determine if the move is valid.
   * @param piece the piece being moved.
   * @param currentRow the original row which the piece is sitting.
   * @param currentCol the original column which the piece is sitting.
   * @param newRow the row number which the piece is being moved to.
   * @param newRow the column number which the piece is being moved to.
   */
  public void changepawnToknight(String piece, int currentRow, int currentCol, int newRow, int newCol){
    if( newRow == 0){
      piece = super.getBLACK_KNIGHT();
      legalpawnMove(piece, currentRow, currentCol, newRow, newCol);
    }
    else {
      legalpawnMove(piece, currentRow, currentCol, newRow, newCol);
    }
  }

  /**
   * This method is for moving the white player's pawns.
   * Pawns can move 1 space forward and only if the space is empty.
   * Pawns may take another piece by moving 1 space on a diagonal.
   * @param piece the piece being moved.
   * @param currentRow the original row which the piece is sitting.
   * @param currentCol the original column which the piece is sitting.
   * @param newRow the row number which the piece is being moved to.
   * @param newRow the column number which the piece is being moved to.
   */
  public void legalPawnMove(String piece, int currentRow, int currentCol, int newRow, int newCol){
    if( newCol == currentCol && newRow == currentRow + 1 && emptySpace(newRow, newCol)){
      moveChar(piece, currentRow, currentCol, newRow, newCol);
    }
    if( newRow == currentRow + 1 && (newCol == currentCol + 1 || newCol == currentCol - 1) && !emptySpace(newRow, newCol)){
      moveChar(piece, currentRow, currentCol, newRow, newCol);
    }
  }

  /**
   * This method changes a white pawn to a knight if it reaches the other side of the board.
   * uses legalpawnMove to determine if the move is valid.
   * @param piece the piece being moved.
   * @param currentRow the original row which the piece is sitting.
   * @param currentCol the original column which the piece is sitting.
   * @param newRow the row number which the piece is being moved to.
   * @param newRow the column number which the piece is being moved to.
   */
  public void changePawnToKnight(String piece, int currentRow, int currentCol, int newRow, int newCol){
    if( newRow == 4){
      piece = super.getWHITE_KNIGHT();
      legalPawnMove(piece, currentRow, currentCol, newRow, newCol);
    }
    else {
      legalPawnMove(piece, currentRow, currentCol, newRow, newCol);
    }
  }

  /**
   * This is the main method which allows user to move their pawns.
   * Pawns can move forward 1 space as long as the space is empty.
   * Pawns may move 1 space diagonally only if the space is occupied by an
   * oponents piece. This is how a pawn can take another piece.
   * Pawns will turn into knights if it reaches the opposite side of the board.
   * @param piece the piece being moved.
   * @param currentRow the original row which the piece is sitting.
   * @param currentCol the original column which the piece is sitting.
   * @param newRow the row number which the piece is being moved to.
   * @param newRow the column number which the piece is being moved to.
   * @return true if the attempted move is valid for a pawn, false otherwise.
   */
  public boolean movePawn(String piece, int currentRow, int currentCol, int newRow, int newCol){
    boolean validPawnMove = true;
    if( piece.equals(super.getBLACK_PAWN())){
      changepawnToknight(piece, currentRow, currentCol, newRow, newCol);
      validPawnMove = true;
    }
    else if( piece.equals(super.getWHITE_PAWN())){
      changePawnToKnight(piece, currentRow, currentCol, newRow, newCol);
      validPawnMove = true;
    }
    else{
      validPawnMove = false;
    }
    return(validPawnMove);
  }


  /**
   * Allows a user to move any of their pawns or knights.
   * @param piece the piece being moved.
   * @param currentRow the original row which the piece is sitting.
   * @param currentCol the original column which the piece is sitting.
   * @param newRow the row number which the piece is being moved to.
   * @param newRow the column number which the piece is being moved to.
   */
  public void movePiece(String piece, int currentRow, int currentCol, int newRow, int newCol){
    if( piece.equals(super.getWHITE_PAWN()) || piece.equals(super.getBLACK_PAWN())){
      movePawn(piece, currentRow, currentCol, newRow, newCol);
    }
    else if( piece.equals(super.getWHITE_KNIGHT()) || piece.equals(super.getBLACK_KNIGHT())){
      moveKnight(piece, currentRow, currentCol, newRow, newCol);
    }
  }

  /**
   * Allows to users to make a move which happens at the same time.
   * Each player can move either a pawn or a knight.
   * If the users pieces land on the same spot and are both pawns, then both
   * pieces are removed. If one piece is a pawn and the other a knight, then
   * the knight takes the pawn.
   * @param piece1 the piece that player 1 wants to move.
   * @param currentRow1 the original row where player1's piece is sitting.
   * @param currentCol1 the original column where player1's piece is sitting.
   * @param newRow1 the row number which player 1 wants to move their piece to.
   * @param newRow1 the column number which player 1 wants to move their piece to.
   * @param piece2 the piece that player 2 wants to move.
   * @param currentRow2 the original row where player2's piece is sitting.
   * @param currentCol2 the original column where player2's piece is sitting.
   * @param newRow2 the row number which player 2 wants to move their piece to.
   * @param newRow2 the column number which player 2 wants to move their piece to.
   */
  public void secretMove( String piece1, String piece2, int r1, int c1,
  int newR1, int newC1, int r2, int c2, int newR2, int newC2){
    if( newR1 == newR2 && newC1 == newC2){
      if( (piece1.equals(super.getWHITE_KNIGHT()) && piece2.equals(super.getBLACK_KNIGHT())) || (piece1.equals(super.getBLACK_KNIGHT()) && piece2.equals(super.getWHITE_KNIGHT())) ||
      (piece1.equals(super.getWHITE_PAWN()) && piece2.equals(super.getBLACK_PAWN())) || (piece1.equals(super.getBLACK_PAWN()) && piece2.equals(super.getWHITE_PAWN()) )) {
        super.getBoard()[newR1][newC1] = super.getBLANK();
        super.getBoard()[r1][c1] = super.getBLANK();
        super.getBoard()[r2][c2] = super.getBLANK();
      }
      else if( (piece1.equals(super.getWHITE_KNIGHT()) && piece2.equals(super.getBLACK_PAWN())) || (piece1.equals(super.getBLACK_KNIGHT()) && piece2.equals(super.getWHITE_PAWN()))){
        super.getBoard()[newR1][newC1] = piece1;
        super.getBoard()[r1][c1] = super.getBLANK();
        super.getBoard()[r2][c2] = super.getBLANK();
      }
      else if( (piece1.equals(super.getBLACK_PAWN()) && piece2.equals(super.getWHITE_KNIGHT())) || (piece1.equals(super.getWHITE_PAWN()) && piece2.equals(super.getBLACK_KNIGHT()))){
        super.getBoard()[newR1][newC1] = piece2;
        super.getBoard()[r1][c1] = super.getBLANK();
        super.getBoard()[r2][c2] = super.getBLANK();
      }
    }
    else if (newR1 == r2 && r1 == newR2 && c1 == newC2 && newC1 == c2){
        super.getBoard()[newR1][newC1] = piece1;
        super.getBoard()[newR2][newC2] = piece2;
    }
    else {
	movePiece(piece1, r1, c1, newR1, newC1);
        movePiece(piece2, r2, c2, newR2, newC2);

    }
  }

  /**
   * Checks that the user is making a valid move relative to the type of piece they want to move.
   * @param piece1 the piece that player wants to move.
   * @param r1 the original row where players piece is.
   * @param c1 the original column where players piece is.
   * @param newR1 the row number which the player wants the piece to move to.
   * @param newC1 the column number which the player wants the piece to move to.
   * @return true if move is valid, false if it is not.
   */
  public boolean isValidMove(String piece1, int r1, int c1, int newR1, int newC1){
    boolean validMove = false;
    if( movePawn(piece1, r1, c1, newR1, newC1) == true || moveKnight(piece1, r1, c1, newR1, newC1) == true){
      validMove = true;
    }
    return(validMove);
  }

  /**
   * Moves the pieces simultaneously for the human vs human game option.
   * @param player1 the first human player who plays with the white pieces.
   * @param player2 the second human player who plays with the black pieces.
   */
  public void humanPlayerMove(HumanPlayer player1, HumanPlayer player2){
    System.out.println("Player 1: ");
    String whitePiece = player1.getPiece();
    int cRow1 = player1.getCurrentRow();
    int cCol1 = player1.getCurrentColumn();
    while( !super.inputMatchesBoard(whitePiece, cRow1, cCol1)){
      System.out.println("That spot on the board does not have that piece. Pick a location where your piece exists: ");
      cRow1 = player1.getCurrentRow();
      cCol1 = player1.getCurrentColumn();
    }
    int nRow1 = player1.getNewRow();
    int nCol1 = player1.getNewColumn();
    while( !this.isValidMove(whitePiece, cRow1, cCol1, nRow1, nCol1) ) {
      System.out.println("That is not a valid move. Please pick a valid spot for your piece: ");
      nRow1 = player1.getNewRow();
      nCol1 = player1.getNewRow();
    }
    System.out.println("Player 2: ");
    String blackPiece = player2.getPiece();
    int cRow2 = player2.getCurrentRow();
    int cCol2 = player2.getCurrentColumn();
    while( !super.inputMatchesBoard(blackPiece, cRow2, cCol2)){
      System.out.println("That spot on the board does not have that piece. Pick a location where your piece exists: ");
      cRow2 = player2.getCurrentRow();
      cCol2 = player2.getCurrentColumn();
    }
    int nRow2 = player2.getNewRow();
    int nCol2 = player2.getNewColumn();
    System.out.println("Player 2: piece, new R, new C: " + blackPiece + nRow2 + nCol2);
    while( !this.isValidMove(blackPiece, cRow2, cCol2, nRow2, nCol2) ) {
      System.out.println("That is not a valid move. Please pick a valid spot for your piece: ");
      nRow2 = player2.getNewRow();
      nCol2 = player2.getNewRow();
    }
    this.secretMove(whitePiece, blackPiece, cRow1, cCol1, nRow1,
    nCol1, cRow2, cCol2, nRow2, nCol2);
  }

  /**
   * Makes the pieces simoultaneously for the human vs. computer game option.
   * @param computer the computer player which plays with the white pieces.
   * @param player2 the human player which plays with the black pieces.
   */
  public void computerPlayerMove(ComputerPlayer computer, HumanPlayer player2){
    computer.computeNextMove();
    String blackPiece = player2.getPiece();
    int cRow2 = player2.getCurrentRow();
    int cCol2 = player2.getCurrentColumn();
    while (!super.inputMatchesBoard(blackPiece, cRow2, cCol2)) {
      System.out.println(
      "That spot on the board does not have that piece. Pick a location where your piece exists: ");
      cRow2 = player2.getCurrentRow();
      cCol2 = player2.getCurrentColumn();
    }
    int nRow2 = player2.getNewRow();
    int nCol2 = player2.getNewColumn();
    while( !this.isValidMove(blackPiece, cRow2, cCol2, nRow2, nCol2) ) {
      System.out.println("That is not a valid move. Please pick a valid spot for your piece: ");
      nRow2 = player2.getNewRow();
      nCol2 = player2.getNewRow();
    }
    this.secretMove(computer.getPiece(), blackPiece, computer.getCurrentRow(), computer.getCurrentColumn(), computer.getNewRow(), computer.getNewColumn(), cRow2, cCol2, nRow2, nCol2);
  }

}
