import static org.junit.Assert.*;
import java.util.*;
import java.io.*;
import org.junit.Test;

public class GameConfigTest {

	/**
	 * Testing getBoard
	 */
	@Test
	public void test_getter_board() {
		GameConfig g = new GameConfig();
		String[][] expected = {
					{"wK", "wP", "wP", "wP", "wK"},
					{ "wP", "__", "__", "__",  "wP"},
					{"__", "__", "__", "__", "__" },
					{"bP", "__", "__", "__", "bP"},
					{"bK", "bP", "bP","bP", "bK"}};

		assertEquals("Expected to be the initial board ", expected ,g.getBoard());
	}

	/**
	 * Testing isOnBoard
	 */
	@Test
	public void test_isOnBoard_offBoardColumn() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be false.", false, g.isOnBoard(3,6));
	}

	@Test
	public void test_isOnBoard_offBoardRow() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be false.", false, g.isOnBoard(7,2));
	}

	@Test
	public void test_isOnBoard_onBoard() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be true.", true, g.isOnBoard(3,4));
	}

	/**
	 * Testing getWHITE_KNIGHT
	 */
	@Test
	public void test_getter_whiteKnight() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be white knight. ", "wK" ,g.getWHITE_KNIGHT());
	}


	/**
	 * Testing getWHITE_PAWN
	 */
	@Test
	public void test_getter_whitePawn() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be white pawn.", "wP" ,g.getWHITE_PAWN());
	}

	/**
	 * Testing getBLACK_KNIGHT
	 */
	@Test
	public void test_getter_blackKnight() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be black knight. ", "bK" ,g.getBLACK_KNIGHT());
	}

	/**
	 * Testing getBLACK_PAWN
	 */
	@Test
	public void test_getter_blackPawn() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be black pawn.", "bP" ,g.getBLACK_PAWN());
	}

	/**
	 * Testing getBLANK
	 */
	@Test
	public void test_getter_blank() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be blank.", "__" ,g.getBLANK());
	}

	/**
	 * Testing noBlackPawns
	 */
	@Test
	public void test_noBlackPawns_initialBoard() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be false.", false, g.noBlackPawns());
	}

	/**
	 * Testing noBlackPawns
	 */
	@Test
	public void test_noBlackPawns_zeroBlackPawns() {
		GameConfig g = new GameConfig();
		g.getBoard()[4][1] = "__";
		g.getBoard()[4][2] = "__";
		g.getBoard()[4][3] = "__";
		g.getBoard()[3][0] = "__";
		g.getBoard()[3][4] = "__";
		assertEquals("Expected to be true.", true, g.noBlackPawns());
	}

	/**
	 * Testing noWhitePawns
	 */
	@Test
	public void test_noWhitePawns_initialBoard() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be false.", false, g.noWhitePawns());
	}

	/**
	 * Testing noWhitePawns
	 */
	@Test
	public void test_noWhitePawns_zero() {
		GameConfig g = new GameConfig();
		g.getBoard()[0][1] = "__";
		g.getBoard()[0][2] = "__";
		g.getBoard()[0][3] = "__";
		g.getBoard()[1][0] = "__";
		g.getBoard()[1][4] = "__";
		assertEquals("Expected to be true.", true, g.noWhitePawns());
	}

	/**
	 * Testing gameWon
	 */
	@Test
	public void test_gameWon_initialBoard() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be false.", false, g.gameWon());
	}

	/**
	 * Testing inputMatchesBoard
	 */
	@Test
	public void test_inputMatchesBoard_initialBoard_whitePawn() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be true.", true, g.inputMatchesBoard("wP", 0, 1));
	}

	@Test
	public void test_inputMatchesBoard_initialBoard_whiteKnight() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be true.", true, g.inputMatchesBoard("wK", 0, 4));
	}

	@Test
	public void test_inputMatchesBoard_initialBoard_blackPawn() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be true.", true, g.inputMatchesBoard("bP", 4, 3));
	}

	@Test
	public void test_inputMatchesBoard_initialBoard_blackKnight() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be true.", true, g.inputMatchesBoard("bK", 4, 0));
	}

	@Test
	public void test_inputMatchesBoard_initialBoard_noWhitePawn() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be false.", false, g.inputMatchesBoard("wP", 0, 0));
	}

	@Test
	public void test_inputMatchesBoard_initialBoard_noWhiteKnight() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be false.", false, g.inputMatchesBoard("wK", 2, 2));
	}

	@Test
	public void test_inputMatchesBoard_initialBoard_noBlackPawn() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be false.", false, g.inputMatchesBoard("bP", 3, 2));
	}

	@Test
	public void test_inputMatchesBoard_initialBoard_noBlackKnight() {
		GameConfig g = new GameConfig();
		assertEquals("Expected to be false.", false, g.inputMatchesBoard("bK", 4, 1));
	}

	@Test
	public void test_inputMatchesBoard_removeBlackPawnRow4Column1() {
		GameConfig g = new GameConfig();
		g.getBoard()[4][1] = "__";
		assertEquals("Expected to be false.", false, g.inputMatchesBoard("bP", 4, 1));
	}

	/**
	 * Testing getPlayerType
	 */
	@Test
  public void test_getPlayerType() {
    GameConfig g = new GameConfig();

    String input = "";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    System.setIn(in);

    if (input.equals("Computer")){
      assertEquals("Computer", g.getPlayerType());
    }

    else if (input.equals("Human")){
      assertEquals("Human", g.getPlayerType());
    }
  }

}
