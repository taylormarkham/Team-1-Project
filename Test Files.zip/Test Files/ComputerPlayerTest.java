import static org.junit.Assert.*;

import org.junit.Test;

public class ComputerPlayerTest {

	//Makes sure that the Board is empty.
	@Test
	public void test_boardEmpty() {
		ComputerPlayer play = new ComputerPlayer(new GameConfig());
		// This is what the empty board should look like.
		String[][] expected = { { "wK", "wP", "wP", "wP", "wK" }, { "wP", "__", "__", "__", "wP" },
				{ "__", "__", "__", "__", "__" }, { "bP", "__", "__", "__", "bP" }, { "bK", "bP", "bP", "bP", "bK" } };
		//This is what the board actually looks like.
		String[][] real = play.getBoard().getBoard();

		//Calling the method to make sure the board is correct.
		checkArrayEquals(expected, real);
	}
	// Verifying that the expected board matches the actual board.
	private void checkArrayEquals(String[][] expected, String[][] real) {
		assertEquals(expected.length, real.length);
		for (int i = 0; i < expected.length; i++) {
			assertEquals(expected[i].length, real[i].length);
			for (int j = 0; j < expected[i].length; j++) {
				assertEquals(expected[i][j], real[i][j]);
			}
		}
	}

	@Test
	public void test_computeNextMove() {
		// Sets up by creating a new computer player.
		ComputerPlayer play = new ComputerPlayer(new GameConfig());
		// Executes the method being tested, computeNextMove.
		play.computeNextMove();
		// Verifies that the computer makes the correst move.
		assertEquals("wK", play.getPiece());
		assertEquals(0, play.getCurrentRow());
		assertEquals(0, play.getCurrentColumn());
		assertEquals(1, play.getNewRow());
		assertEquals(2, play.getNewColumn());
	}

 	@Test
	public void test_computeNextMove2(){
		// Sets up the test by creating a new GameConfig, Move, and ComputerPlayer.
	  GameConfig game = new GameConfig();
	  Move move = new Move();
		ComputerPlayer play = new ComputerPlayer(game);
		// Executes computeNextMove.
		play.computeNextMove();
		move.secretMove(play.getPiece(), "bP", play.getCurrentRow(), play.getCurrentColumn(), play.getNewRow(), play.getNewColumn(), 4, 1, 3, 1);

		play.computeNextMove();
		move.secretMove(play.getPiece(), "bP", play.getCurrentRow(), play.getCurrentColumn(), play.getNewRow(), play.getNewColumn(), 3, 1, 2, 1);

		play.computeNextMove();
		move.secretMove(play.getPiece(), "bP", play.getCurrentRow(), play.getCurrentColumn(), play.getNewRow(), play.getNewColumn(), 3, 0, 2, 0);

		play.computeNextMove();
		move.secretMove(play.getPiece(), "bP", play.getCurrentRow(), play.getCurrentColumn(), play.getNewRow(), play.getNewColumn(), 2,0, 1, 1);
		// Verifies that the computer will take a bP near it, which are the moves made.
		assertEquals("wK", play.getPiece());
		assertEquals(0, play.getCurrentRow());
		assertEquals(4, play.getCurrentColumn());
		assertEquals(2, play.getNewRow());
		assertEquals(3, play.getNewColumn());
	}

	@Test
	public void test_computeNextMove3() {
		// Sets up the test by creating a GameConfig, Move, and ComputerPlayer.
    GameConfig game = new GameConfig();
    Move move = new Move();
	 ComputerPlayer play = new ComputerPlayer(game);
	 // Executes the method being tested, computeNextMove
	 play.computeNextMove();
	 move.secretMove(play.getPiece(), "bP", play.getCurrentRow(), play.getCurrentColumn(), play.getNewRow(), play.getNewColumn(), 3, 0, 3, 1);

	 play.computeNextMove();
	 move.secretMove(play.getPiece(), "bP", play.getCurrentRow(), play.getCurrentColumn(), play.getNewRow(), play.getNewColumn(), 3, 1, 3, 2);

	 play.computeNextMove();
	 move.secretMove(play.getPiece(), "bP", play.getCurrentRow(), play.getCurrentColumn(), play.getNewRow(), play.getNewColumn(), 4, 1, 3, 1);

	 play.computeNextMove();
	 move.secretMove(play.getPiece(), "bP", play.getCurrentRow(), play.getCurrentColumn(), play.getNewRow(), play.getNewColumn(), 4, 2, 3, 2);

	 play.computeNextMove();
	 move.secretMove(play.getPiece(), "bP", play.getCurrentRow(), play.getCurrentColumn(), play.getNewRow(), play.getNewColumn(), 3, 2 , 2, 2);
	 // Verifies that move matches what's expected.
	 assertEquals("wP", play.getPiece());
	 assertEquals(2, play.getCurrentRow());
	 assertEquals(1, play.getCurrentColumn());
	 assertEquals(3, play.getNewRow());
	 assertEquals(2, play.getNewColumn());
 }

	@Test
	//passing blank space in the beginning.
	public void test_movementKnight() {
		// Sets up the test by creating a new ComputerPlayer.
		ComputerPlayer play = new ComputerPlayer(new GameConfig());
		// Executes movementsKnight.
		//what is being killed is first one.
		play.movementKnight("__", 0, 0, 1, 2, 0);
		// Verifies that the movement is correct.
		assertEquals("wK", play.getPiece());
		assertEquals(0, play.getCurrentRow());
		assertEquals(0, play.getCurrentColumn());
		assertEquals(1, play.getNewRow());
		assertEquals(2, play.getNewColumn());
	}

	@Test
	//passing blank space in the beginning.
	public void test_movementKnight2() {
		// Sets up the test by creating a new ComputerPlayer.
		ComputerPlayer play = new ComputerPlayer(new GameConfig());
		// Executes movementKnight.
		//what is being killed is first one.
		play.movementKnight("__", 4, 4, 3, 2, 0);
		// Verifies that the movement is what's expected.
		assertEquals("wK", play.getPiece());
		assertEquals(4, play.getCurrentRow());
		assertEquals(4, play.getCurrentColumn());
		assertEquals(3, play.getNewRow());
		assertEquals(2, play.getNewColumn());
	}

	@Test
	public void test_movePawn() {
		// Sets up the test by creating a new ComputerPlayer.
		ComputerPlayer play = new ComputerPlayer(new GameConfig());
		// Executes the method being tested, movementPawn.
		play.movementPawn("__", 0, 1, 1 ,1 , 0);
		// Checks that the movement is correct.
		assertEquals("wP", play.getPiece());
		assertEquals(0, play.getCurrentRow());
		assertEquals(1, play.getCurrentColumn());
		assertEquals(1, play.getNewRow());
		assertEquals(1, play.getNewColumn());
	}

}
