import static org.junit.Assert.*;

import org.junit.Test;

public class MoveTest {

	@Test
	public void test_validInputBlack_whitePawn() {
		// Sets up the test by creating a new Move.
		Move m = new Move();
		// Executes and verifies the method, validInputBlack, with a bad input.
		assertEquals("Expected to be false.", false, m.validInputBlack("wP"));
	}

	@Test
	public void test_validInputBlack_blackPawn() {
		// Sets up the test by creating a new Move.
		Move m = new Move();
		// Executes and checks the method, validInputBlack, with good input (black pawn).
		assertEquals("Expected to be true.", true, m.validInputBlack("bP"));
	}

	@Test
	public void test_validInputBlack_blackKnight() {
		// Sets up the test by creating a new Move.
		Move m = new Move();
		// Executes and verifies the method validInputBlack, with good input (black knight).
		assertEquals("Expected to be true.", true, m.validInputBlack("bK"));
	}

	@Test
	public void test_validInputWhite_blackPawn() {
		// Sets up the test by creating a new Move.
		Move m = new Move();
		// Executes and checks the method, validInputWhite, with bad input.
		assertEquals("Expected to be false.", false, m.validInputWhite("bP"));
	}

	@Test
	public void test_validInputWhite_whitePawn() {
		// Sets up the test by creating a new Move.
		Move m = new Move();
		// Executes and verifies the method validInputWhite, with good input (white pawn).
		assertEquals("Expected to be true.", true, m.validInputWhite("wP"));
	}

	@Test
	public void test_validInputWhite_whiteKnight() {
		// Sets up the test by creating a new Move.
		Move m = new Move();
		// Executes and verifies the method validInputBlack, with good input (white knight).
		assertEquals("Expected to be true.", true, m.validInputWhite("wK"));
	}

	@Test
	public void test_emptySpace_intialBoard_notEmpty() {
		// Sets up the test by creating a new Move.
		Move m = new Move();
		// Executes and verifies the method.
		assertEquals("Expected to be false.", false, m.emptySpace(0,1));
	}

	@Test
	public void test_emptySpace_intialBoard_empty() {
		// Sets up the test by creating a new Move.
		Move m = new Move();
		// Executes and verifies the method.
		assertEquals("Expected to be true.", true, m.emptySpace(3,1));
	}

	@Test
	public void test_moveKnight_row0column0_to_row2column1() {
		// Sets up the test by creating a new Move.
		Move m = new Move();
		// Executes and verifies that the method moveKnight makes correct move.
		assertEquals("Expected to be true.", true, m.moveKnight("wK",0, 0, 2, 1));
	}

	@Test
	public void test_moveKnight_row0column0_to_row2column2() {
		// Sets up the test by creating a new Move.
		Move m = new Move();
		// Executes and checks the method moveKnight with bad inputs.
		assertEquals("Expected to be false.", false, m.moveKnight("wK",0, 0, 2, 2));
	}

	@Test
	public void test_movePawn_row0column3_to_row1column3() {
		// Sets up the test by creating a new Move.
		Move m = new Move();
		// Executes and checks that movePawn makes expected move.
		assertEquals("Expected to be true.", true, m.movePawn("wP",0, 3, 1, 3));
	}

	@Test
	public void test_isValidMove_whitePawn_from_row0column2_to_row1column2() {
		// Sets up the test by creating a new Move.
		Move m = new Move();
		// Executes and checks the method isValidMove with good inputs.
		assertEquals("Expected to be true.", true, m.isValidMove("wP",0, 2, 1, 2));
	}

}
